package pe.edu.upc.demosi61clase.dtos;

public class PointByMovieDTO {
    private String nameMovie;
    private int sumPoints;

    public String getNameMovie() {
        return nameMovie;
    }

    public void setNameMovie(String nameMovie) {
        this.nameMovie = nameMovie;
    }

    public int getSumPoints() {
        return sumPoints;
    }

    public void setSumPoints(int sumPoints) {
        this.sumPoints = sumPoints;
    }
}
