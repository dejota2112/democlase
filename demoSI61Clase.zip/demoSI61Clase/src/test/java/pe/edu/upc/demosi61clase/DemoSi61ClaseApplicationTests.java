package pe.edu.upc.demosi61clase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSi61ClaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
